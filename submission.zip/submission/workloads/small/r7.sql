CREATE TABLE r7 (c0 bigint,c1 bigint,c2 bigint,c3 bigint,c4 bigint,c5 bigint);
copy r7 from 'r7.tbl' delimiter '|';
