CREATE TABLE r11 (c0 bigint,c1 bigint,c2 bigint);
copy r11 from 'r11.tbl' delimiter '|';
