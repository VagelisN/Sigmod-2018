CREATE TABLE r3 (c0 bigint,c1 bigint,c2 bigint,c3 bigint);
copy r3 from 'r3.tbl' delimiter '|';
