CREATE TABLE r6 (c0 bigint,c1 bigint);
copy r6 from 'r6.tbl' delimiter '|';
