CREATE TABLE r9 (c0 bigint,c1 bigint,c2 bigint,c3 bigint,c4 bigint);
copy r9 from 'r9.tbl' delimiter '|';
