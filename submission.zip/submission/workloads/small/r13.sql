CREATE TABLE r13 (c0 bigint,c1 bigint,c2 bigint,c3 bigint,c4 bigint,c5 bigint,c6 bigint);
copy r13 from 'r13.tbl' delimiter '|';
