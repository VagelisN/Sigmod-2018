CREATE TABLE r2 (c0 bigint,c1 bigint,c2 bigint,c3 bigint);
copy r2 from 'r2.tbl' delimiter '|';
